This is lab quiz.
